const InstructorDashboard = () => {
  return <h2>Instructor Dashboard</h2>;
};

export default InstructorDashboard;
