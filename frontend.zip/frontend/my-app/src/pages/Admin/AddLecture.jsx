const AddLecture = () => {
  return <div>Assign Lecture Page</div>;
};

export default AddLecture;
