const AdminDashboard = () => {
  return <h2>Admin Dashboard</h2>;
};

export default AdminDashboard;
