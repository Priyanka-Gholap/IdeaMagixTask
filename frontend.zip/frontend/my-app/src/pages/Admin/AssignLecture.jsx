const AssignLecture = () => {
  return <div>Assign Lecture Page</div>;
};

export default AssignLecture;
